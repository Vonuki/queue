<?php

return [
    'adminEmail' => 'info@easymatic.su',
    'senderEmail' => 'robot@easymatic.su',
    'senderName' => 'Robot',
];
