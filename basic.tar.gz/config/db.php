<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=meshdomr.mysql;dbname=meshdomr_queue',
    'username' => 'meshdomr_queue',
    'password' => 'WUac+Nh3',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
